# DOCUMENTATION - nginx-snmp-chain

PoC for a two-part chain. An unauthenticated client reaches nginx, nginx reverse-proxies the
snmp_exporter `/snmp` endpoint unaltered, and (a) the exporter's SSRF still fires, delivering the
configured management community in clear to a host:port the attacker chose, while (b) nginx
persists the probed `target` and the invoked `auth` in its access_log. The mechanism is
config-dependent, not inherent: the mitigation exists but has to be written, and the entry
shows that the obvious `if` alone is not enough.

- **Class:** chained unauthenticated SSRF plus log persistence through an nginx reverse proxy.
- **Impact ceiling:** credential and reconnaissance exposure (the community is delivered in
  clear; `target` and `auth` are persisted in logs), not RCE.
- **Auth / precondition:** no HTTP auth on the exporter's `/snmp`; any client with network egress
  to the published port. Config-dependent.
- **Default config:** NO. It is config-dependent: the mitigation exists but must be written.
- **Target:** a deployment that reverse-proxies snmp_exporter through a bare nginx `proxy_pass`.

## 1. Position yourself in the directory

This entry lives at `nginx/nginx-snmp-chain/`. From the kit root:

```
cd nginx/nginx-snmp-chain
```

All commands below are relative to this directory (or, where stated, to the kit root), and no
absolute path is used.

## 2. Files and what each one does

| File | Function |
|---|---|
| `docker-compose.yml` | exporter plus device plus nginx (bad, published 49691) plus nginx-deny plus nginx-fixed plus attacker. |
| `Dockerfile` | attacker/device image: `python:3.12-slim` pinned digest plus a hand-rolled BER codec. |
| `snmp/snmpchain.py` | BER SNMPv2c agent and sink (stdlib only). |
| `snmp/snmp_exporter.yml` | auths `public_v2` (community `public`) and `mgmt_v2` (community `SECRETO_SENTINEL_123`). |
| `snmp/httpget.py` | HTTP fetcher used by the device/attacker image (present in the directory; not listed in the README's layout table). |
| `nginx/nginx-bad.conf` | `proxy_pass`, default log format (the vulnerable deployment). |
| `nginx/nginx-deny.conf` | `if ($arg_target != "") { return 403; }`, default log format. |
| `nginx/nginx-fixed.conf` | the `if` plus an args-less `log_format "$request_method $uri"`. |
| `exploit.sh` | orchestration: up, sink, attack via 49691, two contraprobes, verdict. |
| `README.md` | The entry's source-of-truth document (mechanism, legs, rc contract). |
| `SPEC.md` | The entry's spec sheet. |
| `capture/` | Measured output (created at runtime): `verdict.json`, `leak`, `leak-hex.txt`, the three nginx logs, `compose-up.log`. |

## 3. The target source

The entry does not state a file:line coordinate for the exporter's `/snmp` handler or for nginx's
`proxy_pass`. The mechanism is described at the level of behavior: the exporter's
`/snmp?target=...&auth=...&module=...` needs no HTTP auth, the `auth` profile selects a
configured SNMPv2c community, and the exporter sends a GetBulk to `target` carrying that
community in clear. A bare nginx `proxy_pass` forwards the request unchanged, so the SSRF
survives the proxy and nginx adds no query-string deny; the default access_log format records
`$request`, so the full query string (target plus auth) is written to disk. The build context is
the entry directory. Images are fixed by digest (`prom/snmp-exporter`, `nginx`, `python`).

## 4. Build and start

```
docker compose -f docker-compose.yml build
docker compose -f docker-compose.yml up -d
```

or, as the single source of truth, `./exploit.sh`, which brings the stack up with `--build`,
runs the attack and the two contraprobes, and writes the verdict. Published host port is 49691.
Requires Docker Compose.

### Exit contract

| rc | Meaning |
|---|---|
| `0` | exporter functional, SSRF leak demonstrated (community == configured sentinel), bad-nginx persisted target+auth, and both contraprobes discriminated. |
| `1` | Not demonstrated (honest negative). |

## 5. Reproduce - execution order

1. **P0.** The exporter scrapes the real device, returning HTTP 200: the exporter is functional.
2. **P1.** The host requests `127.0.0.1:49691/snmp?...`; the attacker's sink captures the
   datagram, the community is read back from the raw bytes, and the bad-nginx access_log is
   shown to hold the target and auth.
3. **C1.** Via `nginx-deny`: `403` and zero datagrams, but the access_log still holds the target,
   because the bare `if` does not stop the log line.
4. **C2.** Via `nginx-fixed`: `403`, zero datagrams, and the access_log line carries neither
   target nor auth nor the secret.

## 6. The vector(s) and the controls

Vectors, from the README's legs:

| Vector | Request | Auth | Observed |
|---|---|---|---|
| SSRF community leak | `GET 127.0.0.1:49691/snmp?target=...&auth=mgmt_v2&module=...` | none | attacker's sink captures the datagram; community == `SECRETO_SENTINEL_123` |
| Log persistence | the same request through bad-nginx | none | access_log holds `target` and `auth` |

Controls (the README's contraprobes):

| Control | Setup | Expected | Observed |
|---|---|---|---|
| C1 | `nginx-deny`: `if ($arg_target != "") { return 403; }` | `403`, zero datagrams | `403`, zero datagrams, but the log still holds the target |
| C2 | `nginx-fixed`: the `if` plus args-less `log_format` | `403`, zero datagrams, no secret in the log | matches; zero target/auth hits in the log |

## 7. Conditions

1. The exporter's `/snmp` endpoint needs no HTTP auth, so an unauthenticated client reaches it.
2. nginx forwards the request unchanged (a bare `proxy_pass` with no query-string deny).
3. The nginx access_log uses the default format, which records `$request` (the full query
   string, including target and auth).
4. The `auth` profile is configured with a management community, so the leak is a real secret and
   not a public placeholder.

## 8. Against a real / deployed target

(a) **Target characteristics.** A deployment that reverse-proxies snmp_exporter through nginx
without a query-string deny and with the default log format. The entry does not measure a
deployment that already carries the args-less log format.

(b) **Chain position.** This is a reconnaissance and credential-capture step. The leaked
management community can be used to read the management device, but that read is out of scope
here and is a separate entry (`snmp-exporter/snmp-exporter-read-bypass-leak/`).

(c) **Build / run against a real target.** Send the same `/snmp?target=...&auth=...` request
through the exposed proxy and watch for a datagram at an attacker-controlled listener; then read
the nginx access_log for the query string.

(d) **What a PoC would have to change.** The target and the attacker's sink address; the
`auth` profile name must match the target's configured profiles.

## 9. Measured / not measured

Measured (from `capture/verdict.json`, timestamp 2026-10-09T15:34:55Z, `rc=0`):
`p0_exporter_scrapes_device=1`, `p1_ssrf_community_leaked_to_sink=1` with
`p1_community_value=SECRETO_SENTINEL_123`, `p1_bad_nginx_log_persists_target_and_auth=1`. For
`c1_deny_only`: `HTTP 403`, `sink_delta=0`, `log_still_has_target=1`. For
`c2_deny_plus_argsless_log`: `HTTP 403`, `sink_delta=0`, `log_secret_target_auth_hits=0`.
Published port 49691.

