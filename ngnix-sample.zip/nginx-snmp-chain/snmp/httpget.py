#!/usr/bin/env python3
import sys
import urllib.request
import urllib.error

url = sys.argv[1]
try:
    r = urllib.request.urlopen(url, timeout=8)
    sys.stdout.write("HTTP %d\n" % r.status)
except urllib.error.HTTPError as e:
    sys.stdout.write("HTTP %d\n" % e.code)
except Exception:
    sys.stdout.write("NO_RESPONSE\n")
