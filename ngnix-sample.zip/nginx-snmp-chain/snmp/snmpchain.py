#!/usr/bin/env python3
import bisect
import os
import re
import socket
import sys
from collections import namedtuple

SECRET = os.environ.get("SNMP_SECRET", "SECRETO_SENTINEL_123")
WRITABLE = "1.3.6.1.2.1.1.6.0"


def ber_len(n):
    if n < 0x80:
        return bytes([n])
    out = b""
    while n:
        out = bytes([n & 0xFF]) + out
        n >>= 8
    return bytes([0x80 | len(out)]) + out


def tlv(tag, payload):
    return bytes([tag]) + ber_len(len(payload)) + payload


def read_tlv(buf, i):
    if i is None or i + 2 > len(buf):
        return None, None, None
    tag = buf[i]
    length = buf[i + 1]
    i += 2
    if length & 0x80:
        k = length & 0x7F
        if k == 0 or i + k > len(buf):
            return None, None, None
        length = int.from_bytes(buf[i:i + k], "big")
        i += k
    if i + length > len(buf):
        return None, None, None
    return tag, buf[i:i + length], i + length


def enc_int_bytes(n):
    if n == 0:
        return b""
    ln = 1
    while not (-(1 << (8 * ln - 1)) <= n < (1 << (8 * ln - 1))):
        ln += 1
    return n.to_bytes(ln, "big", signed=True)


def dec_int(b, signed=True):
    return int.from_bytes(b, "big", signed=signed) if b else 0


def oid_body(dotted):
    parts = [int(x) for x in dotted.split(".")]
    body = bytes([parts[0] * 40 + parts[1]])
    for p in parts[2:]:
        if p == 0:
            body += b"\x00"
            continue
        chunk = [p & 0x7F]
        p >>= 7
        while p:
            chunk.insert(0, (p & 0x7F) | 0x80)
            p >>= 7
        body += bytes(chunk)
    return body


def enc_oid(dotted):
    return tlv(0x06, oid_body(dotted))


def oid_tuple(dotted):
    return tuple(int(x) for x in dotted.split("."))


def in_subtree(oid, root):
    t, r = oid_tuple(oid), oid_tuple(root)
    return t[:len(r)] == r


def dec_oid(content):
    if not content:
        return None
    out, val, first, octetos = [], 0, True, 0
    for b in content:
        octetos += 1
        val = (val << 7) | (b & 0x7F)
        if b & 0x80:
            continue
        if first:
            out.extend([val // 40, val % 40] if octetos == 1 else [2, val - 80])
            first = False
        else:
            out.append(val)
        val, octetos = 0, 0
    return ".".join(str(x) for x in out) if out else None


T_INTEGER = 0x02
T_OCTETS = 0x04
T_OID = 0x06
T_IPADDR = 0x40
T_COUNTER32 = 0x41
T_GAUGE32 = 0x42
T_TIMETICKS = 0x43
T_NO_SUCH_OBJECT = 0x80
T_NO_SUCH_INSTANCE = 0x81
T_END_OF_MIB = 0x82
END_TAGS = (T_NO_SUCH_OBJECT, T_NO_SUCH_INSTANCE, T_END_OF_MIB)

VALUE_TAGS = (T_INTEGER, T_OCTETS, T_OID, T_IPADDR,
              T_COUNTER32, T_GAUGE32, T_TIMETICKS)

TAG_NAMES = {
    T_INTEGER: "INTEGER",
    T_OCTETS: "OCTET STRING",
    T_OID: "OBJECT IDENTIFIER",
    T_IPADDR: "IpAddress",
    T_COUNTER32: "Counter32",
    T_GAUGE32: "Gauge32",
    T_TIMETICKS: "TimeTicks",
    T_NO_SUCH_OBJECT: "noSuchObject",
    T_NO_SUCH_INSTANCE: "noSuchInstance",
    T_END_OF_MIB: "endOfMibView",
}


def tag_name(tag):
    return TAG_NAMES.get(tag, "tag=0x%02X" % (tag if tag is not None else 0))


def pretty(tag, value):
    if tag == T_INTEGER:
        return str(dec_int(value, signed=True))
    if tag in (T_COUNTER32, T_GAUGE32, T_TIMETICKS):
        return str(dec_int(value, signed=False))
    if tag == T_IPADDR:
        return ".".join(str(b) for b in value) if len(value) == 4 else value.hex()
    if tag == T_OID:
        return dec_oid(value) or value.hex()
    if tag == T_OCTETS:
        return value.decode("utf-8", "replace")
    if tag in END_TAGS:
        return tag_name(tag)
    return value.hex() if value is not None else "<no value>"


Entry = namedtuple("Entry", "oid tag value")


def _norm(tag, value):
    if tag == T_OCTETS:
        return value.encode() if isinstance(value, str) else value
    if tag == T_OID:
        return oid_body(value) if isinstance(value, str) else value
    if tag == T_IPADDR:
        return bytes(int(p) for p in value.split(".")) if isinstance(value, str) else value
    if tag == T_INTEGER:
        return enc_int_bytes(value) if isinstance(value, int) else value
    if tag in (T_COUNTER32, T_GAUGE32, T_TIMETICKS):
        return value.to_bytes(4, "big", signed=False) if isinstance(value, int) else value
    return value


def _table(root, data):
    out = []
    for col in sorted(data):
        for idx in sorted(data[col]):
            tag, value = data[col][idx]
            out.append(("%s.%d.%d" % (root, col, idx), tag, value))
    return out


_MIB_RAW = [
    ("1.3.6.1.2.1.1.1.0", T_OCTETS, "ACME-Net R9000 v4.2.7-18 (synthetic lab device)"),
    ("1.3.6.1.2.1.1.2.0", T_OID, "1.3.6.1.4.1.99999.1.900"),
    ("1.3.6.1.2.1.1.3.0", T_TIMETICKS, 41234567),
    ("1.3.6.1.2.1.1.4.0", T_OCTETS, "noc@acme-net.invented"),
    ("1.3.6.1.2.1.1.5.0", T_OCTETS, "ACME-R9000-CORE-01"),
    ("1.3.6.1.2.1.1.6.0", T_OCTETS, "initial-fabric-OK"),
    ("1.3.6.1.2.1.2.1.0", T_INTEGER, 3),
]

_MIB_RAW += _table("1.3.6.1.2.1.2.2.1", {
    1: {1: (T_INTEGER, 1), 2: (T_INTEGER, 2), 3: (T_INTEGER, 3)},
    2: {1: (T_OCTETS, "lo"), 2: (T_OCTETS, "eth0-core"),
        3: (T_OCTETS, "eth1-mgmt")},
    3: {1: (T_INTEGER, 24), 2: (T_INTEGER, 6), 3: (T_INTEGER, 6)},
    8: {1: (T_INTEGER, 1), 2: (T_INTEGER, 1), 3: (T_INTEGER, 2)},
    10: {1: (T_COUNTER32, 8123456), 2: (T_COUNTER32, 987654321),
         3: (T_COUNTER32, 0)},
    15: {1: (T_GAUGE32, 0), 2: (T_GAUGE32, 1000000000),
         3: (T_GAUGE32, 1000000000)},
    16: {1: (T_COUNTER32, 8123456), 2: (T_COUNTER32, 654321098),
         3: (T_COUNTER32, 0)},
})

_MIB_RAW += _table("1.3.6.1.2.1.4.21.1", {
    1: {1: (T_INTEGER, 2), 2: (T_INTEGER, 2), 3: (T_INTEGER, 3)},
    2: {1: (T_IPADDR, "0.0.0.0"), 2: (T_IPADDR, "10.10.0.0"),
        3: (T_IPADDR, "172.16.40.0")},
    3: {1: (T_IPADDR, "192.0.2.1"), 2: (T_IPADDR, "10.10.0.1"),
        3: (T_IPADDR, "10.10.0.9")},
    4: {1: (T_INTEGER, 3), 2: (T_INTEGER, 3), 3: (T_INTEGER, 3)},
    5: {1: (T_INTEGER, 2), 2: (T_INTEGER, 2), 3: (T_INTEGER, 2)},
    7: {1: (T_IPADDR, "0.0.0.0"), 2: (T_IPADDR, "255.255.0.0"),
        3: (T_IPADDR, "255.255.255.0")},
})

MIB = tuple(Entry(o, t, _norm(t, v))
            for o, t, v in sorted(_MIB_RAW, key=lambda e: oid_tuple(e[0])))
MIB_INDEX = {e.oid: e for e in MIB}
_MIB_KEYS = [oid_tuple(e.oid) for e in MIB]

assert len(MIB_INDEX) == len(MIB), "duplicate OID in the MIB"
assert WRITABLE in MIB_INDEX, "the writable OID must be in the MIB"


def successor(oid):
    i = bisect.bisect_right(_MIB_KEYS, oid_tuple(oid))
    return MIB[i] if i < len(MIB) else None


def parse_vblist(vbl):
    out, i = [], 0
    while i is not None and i < len(vbl):
        t, vb, n = read_tlv(vbl, i)
        if t != 0x30 or vb is None or n is None:
            break
        t2, oc, n2 = read_tlv(vb, 0)
        oid = dec_oid(oc) if t2 == T_OID and oc else None
        tag, val = None, b""
        if n2 is not None:
            t3, vc, _ = read_tlv(vb, n2)
            if t3 is not None:
                tag, val = t3, vc
        out.append((oid, tag, val))
        i = n
    return out


def parse_varbinds(buf):
    tag, body, _ = read_tlv(buf, 0)
    if tag != 0x30 or body is None:
        return None
    t, ver, n = read_tlv(body, 0)
    if t != T_INTEGER or n is None:
        return None
    t, comm, n = read_tlv(body, n)
    if t != T_OCTETS or n is None:
        return None
    t, pdu, n = read_tlv(body, n)
    if t not in (0xA0, 0xA1, 0xA2, 0xA3, 0xA5) or pdu is None:
        return None
    vbl = None
    _, _, m = read_tlv(pdu, 0)
    if m is not None:
        _, _, m = read_tlv(pdu, m)
    if m is not None:
        _, _, m = read_tlv(pdu, m)
    if m is not None:
        _, vbl, _ = read_tlv(pdu, m)
    return dec_int(ver), comm, t, rid_of(pdu), parse_vblist(vbl) if vbl else []


def rid_of(pdu):
    tr, r, _ = read_tlv(pdu, 0)
    return dec_int(r) if tr == T_INTEGER else 0


def parse_message(buf):
    m = parse_varbinds(buf)
    if not m:
        return None
    ver, comm, pdu, rid, vbs = m
    if not vbs:
        return ver, comm, pdu, rid, None, None
    oid, tag, val = vbs[0]
    return ver, comm, pdu, rid, oid, (val if tag in VALUE_TAGS else None)


def parse_request(buf):
    m = parse_varbinds(buf)
    if not m:
        return None
    ver, comm, pdu, rid, vbs = m
    non_rep = max_rep = 0
    if pdu == 0xA5:
        _, body, _ = read_tlv(buf, 0)
        _, _, n = read_tlv(body, 0)
        _, _, n = read_tlv(body, n)
        _, pdu_body, _ = read_tlv(body, n)
        _, _, n1 = read_tlv(pdu_body, 0)
        _, r1, n2 = read_tlv(pdu_body, n1)
        _, r2, _ = read_tlv(pdu_body, n2)
        non_rep = dec_int(r1)
        max_rep = dec_int(r2)
    return ver, comm, pdu, rid, non_rep, max_rep, vbs


def enc_value(tag, value):
    return tlv(tag, value)


def build_response(rid, comm, varbinds):
    vbl = b"".join(tlv(0x30, enc_oid(o) + enc_value(t, v)) for o, t, v in varbinds)
    pdu = tlv(0xA2, tlv(0x02, (rid & 0xFFFFFFFF).to_bytes(4, "big"))
              + tlv(0x02, bytes([0])) + tlv(0x02, bytes([0])) + tlv(0x30, vbl))
    return tlv(0x30, tlv(0x02, b"\x01") + tlv(0x04, comm) + pdu)


def build_request(comm, pdu_tag, vbs, non_repeaters=0, max_repetitions=10):
    if pdu_tag == 0xA5:
        filler = (tlv(0x02, enc_int_bytes(non_repeaters))
                  + tlv(0x02, enc_int_bytes(max_repetitions)))
    else:
        filler = tlv(0x02, bytes([0])) + tlv(0x02, bytes([0]))
    body = b""
    for oid, tag, value in vbs:
        payload = enc_value(tag, value) if value is not None else tlv(0x05, b"")
        body += tlv(0x30, enc_oid(oid) + payload)
    return tlv(0x30, tlv(0x02, b"\x01") + tlv(0x04, comm.encode())
               + tlv(pdu_tag, tlv(0x02, (0x11223344).to_bytes(4, "big"))
                     + filler + tlv(0x30, body)))


MAX_REPETITIONS_CAP = 64


def bulk_successors(start_oid, max_rep):
    out, cur = [], start_oid
    for _ in range(max_rep):
        e = successor(cur)
        if e is None:
            out.append((start_oid, T_END_OF_MIB, b""))
            continue
        out.append((e.oid, e.tag, e.value))
        cur = e.oid
    return out


def bulk_response(vbs, non_rep, max_rep):
    max_rep = max(1, min(max_rep or 1, MAX_REPETITIONS_CAP))
    entries = []
    for oid, _t, _v in vbs[:max(0, non_rep)]:
        e = MIB_INDEX.get(oid)
        entries.append((e.oid, e.tag, e.value) if e else (oid, T_NO_SUCH_OBJECT, b""))
    for oid, _t, _v in vbs[max(0, non_rep):]:
        entries.extend(bulk_successors(oid, max_rep))
    return entries


IF_COLS = {1: "ifIndex", 2: "ifDescr", 3: "ifType", 8: "ifOperStatus",
           10: "ifInOctets", 15: "ifSpeed", 16: "ifOutOctets"}
IF_TYPES = {6: "ethernetCsmacd", 24: "loopback", 1: "other"}
IF_OPER = {1: "up", 2: "down", 3: "testing", 4: "unknown", 5: "dormant",
           6: "notPresent", 7: "lowerLayerDown"}
RT_COLS = {1: "ipRouteIfIndex", 2: "ipRouteDest", 3: "ipRouteNextHop",
           4: "ipRouteType", 5: "ipRouteProto", 7: "ipRouteMask"}
RT_TYPES = {1: "other", 2: "static", 3: "netMgmt"}
RT_PROTOS = {1: "local", 2: "netMgmt", 3: "icmp", 7: "rip", 8: "isIs",
             11: "bgp", 13: "ospf"}
SYS_COLS = {1: "sysDescr", 2: "sysObjectID", 3: "sysUpTime", 4: "sysContact",
            5: "sysName", 6: "sysLocation"}
VERSION_RE = re.compile(r"\d+\.\d+(\.\d+)?")


def parse_table(rows, root):
    off = len(oid_tuple(root))
    out = {}
    for oid, tag, val in rows:
        p = oid_tuple(oid)
        if len(p) < off + 2:
            continue
        out.setdefault(p[off + 1], {})[p[off]] = (tag, val, oid)
    return out


def leak_server(port, outdir):
    os.makedirs(outdir, exist_ok=True)
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind(("0.0.0.0", port))
    n = 0
    print("[sink] :%d listening, no response (nothing sent to me leaves here)" % port, flush=True)
    while n < 40:
        data, addr = s.recvfrom(65535)
        with open(os.path.join(outdir, "cap.%03d" % n), "wb") as f:
            f.write(data)
        m = parse_message(data)
        if m:
            print("[sink] from %s:%d  pdu=0x%02X  community=%r  %d B"
                  % (addr[0], addr[1], m[2], m[1], len(m[1])), flush=True)
        else:
            print("[sink] from %s:%d  <unparseable> %s" % (addr[0], addr[1], data.hex()), flush=True)
        n += 1


def agent_server(port, statedir=None):
    state = os.path.join(statedir or "/tmp", "agent_value.txt")
    if os.path.exists(state):
        MIB_INDEX[WRITABLE] = MIB_INDEX[WRITABLE]._replace(
            value=open(state, "rb").read())
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind(("0.0.0.0", port))
    ok = bad = 0
    print("[device] :%d listening - only the configured community is accepted" % port, flush=True)
    print("[device] synthetic MIB: %d entries, 1 writable (%s)" % (len(MIB), WRITABLE), flush=True)
    while True:
        data, addr = s.recvfrom(65535)
        r = parse_request(data)
        if not r:
            continue
        _, comm, pdu, rid, non_rep, max_rep, vbs = r
        if comm != SECRET.encode():
            bad += 1
            print("[device] REJECTED from %s  %r  (rejected=%d) - silence"
                  % (addr[0], comm[:24], bad), flush=True)
            continue
        ok += 1
        if not vbs:
            continue
        if pdu == 0xA5:
            entries = bulk_response(vbs, non_rep, max_rep)
            print("[device] AUTHORIZED BULK %s non-rep=%d max-rep=%d -> %d varbind(s) (ok=%d)"
                  % (vbs[0][0], non_rep, max_rep, len(entries), ok), flush=True)
            s.sendto(build_response(rid or 1, comm, entries), addr)
            continue
        oid, tag, newval = vbs[0]
        if pdu == 0xA3:
            if oid != WRITABLE:
                print("[device] SET on non-writable OID %s - no" % oid, flush=True)
                continue
            if tag != T_OCTETS:
                print("[device] SET with %s on %s - no (OCTET STRING only)"
                      % (tag_name(tag), oid), flush=True)
                continue
            with open(state, "wb") as f:
                f.write(newval)
            MIB_INDEX[WRITABLE] = MIB_INDEX[WRITABLE]._replace(value=newval)
            print("[device] SET ACCEPTED %s = %r (ok=%d)" % (oid, newval, ok), flush=True)
        e = MIB_INDEX.get(oid)
        if e is None:
            print("[device] GET %s -> noSuchName" % oid, flush=True)
            continue
        print("[device] AUTHORIZED %s %s -> %r (ok=%d)"
              % ("SET" if pdu == 0xA3 else "GET", oid, e.value, ok), flush=True)
        s.sendto(build_response(rid or 1, comm, [(e.oid, e.tag, e.value)]), addr)


def client(host, port, comm, oid, value=None, bulk=False):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.settimeout(4)
    tag = 0xA3 if value is not None else (0xA5 if bulk else 0xA0)
    vtag = T_OCTETS if value is not None else None
    s.sendto(build_request(comm, tag, [(oid, vtag, value)]), (host, port))
    label = "SET" if value is not None else ("BULK" if bulk else "GET")
    try:
        data, _ = s.recvfrom(65535)
    except socket.timeout:
        print("    %-4s community=%-22r -> NO RESPONSE (not authenticated)" % (label, comm))
        return 1
    m = parse_message(data)
    if not m:
        print("    %-4s community=%-22r -> unparseable response: %s" % (label, comm, data.hex()))
        return 1
    _, _, _, _, roid, rval = m
    rtag = (parse_varbinds(data)[4] or [(None, None, None)])[0][1]
    print("    %-4s community=%-22r -> RESPONSE oid=%s value=%r tag=%s readable=%r"
          % (label, comm, roid, rval, tag_name(rtag),
             pretty(rtag, rval) if rval is not None else None))
    return 0


MAX_WALK_ROUNDS = 200


def walk_collect(host, port, comm, root, max_rep=10):
    rows, cur, prev, s = [], root, None, socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.settimeout(4)
    try:
        for _ in range(MAX_WALK_ROUNDS):
            s.sendto(build_request(comm, 0xA5, [(cur, None, None)], 0, max_rep),
                     (host, port))
            try:
                data, _ = s.recvfrom(65535)
            except socket.timeout:
                return rows, "no_response"
            m = parse_varbinds(data)
            if not m:
                return rows, "unparseable"
            vbs = m[4]
            if not vbs:
                return rows, "no_rows"
            ultimo, corte = None, False
            for oid, tag, val in vbs:
                if tag in END_TAGS or oid is None or not in_subtree(oid, root):
                    corte = True
                    break
                rows.append((oid, tag, val))
                ultimo = oid
            if corte or ultimo is None:
                return rows, None
            if prev is not None and oid_tuple(ultimo) <= oid_tuple(prev):
                return rows, "no_progress"
            prev, cur = ultimo, ultimo
    finally:
        s.close()
    return rows, "rounds_exhausted"


def cmd_walk(host, port, comm, root, max_rep, tab):
    rows, err = walk_collect(host, port, comm, root, max_rep)
    if err == "no_response":
        print("    WALK community=%-22r subtree=%s -> NO RESPONSE (not authenticated)" % (comm, root))
    elif err in ("unparseable", "no_progress", "rounds_exhausted"):
        print("    WALK community=%-22r subtree=%s -> ERROR %s" % (comm, root, err))
    if tab:
        for o, t, v in rows:
            print("%s\t0x%02X\t%s" % (o, t, pretty(t, v)))
        print("#RESULT rows=%d error=%s" % (len(rows), err or "none"))
    else:
        print("    WALK subtree=%s  max-repetitions=%d  ->  %d varbind(s)"
              % (root, max_rep, len(rows)))
        for o, t, v in rows:
            print("      %-26s %-17s %s" % (o, tag_name(t), pretty(t, v)))
        print("    TOTAL rows=%d" % len(rows))
    if err in ("no_response", "unparseable", "no_progress", "rounds_exhausted"):
        return 1
    return 0 if rows else 2


def _num(v, signed=True):
    return dec_int(v, signed=signed) if v else 0


def cmd_recon(host, port, comm):
    subtrees = [
        ("system", "1.3.6.1.2.1.1"),
        ("interfaces", "1.3.6.1.2.1.2.2.1"),
        ("routes", "1.3.6.1.2.1.4.21.1"),
    ]
    print("   credential used: %r  (the one that arrived on the socket, not the config)" % comm)
    print("   Synthetic lab MIB: ACME-Net R9000. No real equipment.")
    print()
    rows_by, error = {}, None
    for name, root in subtrees:
        rows, err = walk_collect(host, port, comm, root, 10)
        if err:
            error = "%s:%s" % (name, err)
            print("   -- %s (%s) -> NO DATA: %s" % (name, root, err))
            rows_by[name] = []
            continue
        rows_by[name] = rows
        print("   -- %s (%s): %d varbind(s) in %d GetBulk"
              % (name, root, len(rows), max(1, -(-len(rows) // 10))))

    sysrows = rows_by["system"]
    byoid = {o: (t, v) for o, t, v in sysrows}
    print()
    print("   IDENTITY AND VERSION (1.3.6.1.2.1.1)")
    for o in sorted(byoid, key=oid_tuple):
        t, v = byoid[o]
        print("     %-14s %-24s %-17s %s"
              % (SYS_COLS.get(oid_tuple(o)[7], o.rsplit(".", 1)[-1]), o,
                 tag_name(t), pretty(t, v)))

    ifaces = parse_table(rows_by["interfaces"], "1.3.6.1.2.1.2.2.1")
    print()
    print("   INTERFACES (ifTable 1.3.6.1.2.1.2.2.1): %d" % len(ifaces))
    for idx in sorted(ifaces):
        c = ifaces[idx]
        def g(col, signed=True, default="-"):
            e = c.get(col)
            return _num(e[1], signed) if e else default
        print("     idx %-3s %-12s ifType=%-4s %-15s oper=%-4s %-8s inOctets=%-11s speed=%s bps"
              % (g(1), pretty(*c[2][:2]), g(3), IF_TYPES.get(g(3, default=0), "?"),
                 g(8), IF_OPER.get(g(8, default=0), "?"),
                 g(10, False), g(15, False)))

    routes_map = parse_table(rows_by["routes"], "1.3.6.1.2.1.4.21.1")
    print()
    print("   ROUTES (ipRouteTable 1.3.6.1.2.1.4.21.1): %d" % len(routes_map))
    no_default = 0
    for idx in sorted(routes_map):
        c = routes_map[idx]
        dest = pretty(*c[2][:2]) if 2 in c else "-"
        hop = pretty(*c[3][:2]) if 3 in c else "-"
        mask = pretty(*c[7][:2]) if 7 in c else "-"
        if dest != "0.0.0.0":
            no_default += 1
        print("     route %-3s dest=%-15s mask=%-15s via=%-15s if=%-4s proto=%s"
              % (idx, dest, mask, hop, _num(c[1][1]) if 1 in c else "-",
                 RT_PROTOS.get(_num(c[5][1]) if 5 in c else 0, "?")))

    sysdesc = pretty(*byoid["1.3.6.1.2.1.1.1.0"]) if "1.3.6.1.2.1.1.1.0" in byoid else ""
    print()
    print("# Read controls (so exploit.sh can assert on numbers):")
    print("KEY=sysdescr=%s" % sysdesc)
    print("KEY=sysdescr_empty=%s" % ("yes" if not sysdesc else "no"))
    print("KEY=sysdescr_version=%s" % ("yes" if VERSION_RE.search(sysdesc or "") else "no"))
    print("KEY=interfaces_distinct=%d" % len(ifaces))
    print("KEY=routes=%d" % len(routes_map))
    print("KEY=routes_non_default=%d" % no_default)
    print("KEY=varbinds_total=%d" % sum(len(rows_by[n]) for n, _ in subtrees))
    print("KEY=error=%s" % (error or "none"))
    return 0 if (error is None and ifaces and routes_map and sysdesc) else 1


if __name__ == "__main__":
    a = sys.argv
    if a[1] == "leak":
        leak_server(int(a[2]), a[3])
    elif a[1] == "agent":
        agent_server(int(a[2]), a[3] if len(a) > 3 else None)
    elif a[1] == "get":
        sys.exit(client(a[2], int(a[3]), a[4], a[5]))
    elif a[1] == "walk":
        sys.exit(cmd_walk(a[2], int(a[3]), a[4], a[5],
                          int(a[6]) if len(a) > 6 else 10, tab=False))
    elif a[1] == "walktab":
        sys.exit(cmd_walk(a[2], int(a[3]), a[4], a[5],
                          int(a[6]) if len(a) > 6 else 10, tab=True))
    elif a[1] == "recon":
        sys.exit(cmd_recon(a[2], int(a[3]), a[4]))
    elif a[1] == "set":
        sys.exit(client(a[2], int(a[3]), a[4], a[5], a[6].encode()))
