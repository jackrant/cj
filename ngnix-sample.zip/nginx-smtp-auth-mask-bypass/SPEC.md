# nginx-smtp-auth-mask-bypass

Candidate spec. Mechanism CONFIRMED from source; PoC MEASURED rc=0 (2026-10-09).

The finding: when the mail server restricts the enabled AUTH methods with
`smtp_auth`, nginx still honours `AUTH PLAIN` and `AUTH LOGIN`, because their
cases in `ngx_mail_smtp_auth()` never test the mask. Only CRAM-MD5 and EXTERNAL
test it. The operator's restriction on the cleartext mechanisms is silently
ineffective against a client that simply asks for them.

## Target

nginx mail (SMTP) module.
`targets/nginx/src/src/mail/ngx_mail_smtp_handler.c:702` (`ngx_mail_smtp_auth`).

Audited tree is 1.31.7; the PoC builds released 1.31.6 (tarball sha256
`974ed529...c9f1`) because the 1.31.7 tarball is not published. The two regions
that matter (`ngx_mail_smtp_handler.c:702-782`, `ngx_mail_smtp_module.c:150-229`)
are byte-identical between 1.31.6 and 1.31.7.

## Mechanism (source-confirmed)

`ngx_mail_smtp_auth()` (`ngx_mail_smtp_handler.c:702`) parses the AUTH method
and switches on it:

- `case NGX_MAIL_AUTH_LOGIN:` (`:727`) -> `smtp_username`, state
  `ngx_smtp_auth_login_username`. **No mask test.**
- `case NGX_MAIL_AUTH_PLAIN:` (`:741`) -> `smtp_next`, state
  `ngx_smtp_auth_plain`. **No mask test.**
- `case NGX_MAIL_AUTH_CRAM_MD5:` (`:748`) -> `if (!(sscf->auth_methods &
  NGX_MAIL_AUTH_CRAM_MD5_ENABLED)) return NGX_MAIL_PARSE_INVALID_COMMAND;`
  (`:750`) — **tests the mask.**
- `case NGX_MAIL_AUTH_EXTERNAL:` (`:769`) -> `if (!(sscf->auth_methods &
  NGX_MAIL_AUTH_EXTERNAL_ENABLED)) return NGX_MAIL_PARSE_INVALID_COMMAND;`
  (`:771`) — **tests the mask.**

The mask (`sscf->auth_methods`) is populated by `smtp_auth` in
`ngx_mail_smtp_module.c` and merged to a default of `PLAIN|LOGIN` at `:160-164`.
It is the same value the EHLO capability line advertises (`:212-217`), which is
why the advertisement and the enforcement disagree: CRAM-MD5 is the only
advertised method, but PLAIN/LOGIN still work.

Rejection of a masked-out method is `smtp_invalid_command[] =
"500 5.5.1 Invalid command"` (`ngx_mail_smtp_handler.c:45`, dispatched at
`:613-616`). Measured on the PoC: `AUTH EXTERNAL` -> `500 5.5.1 Invalid command`.
(Not a 5.5.1 code the original note guessed; the measured string is authoritative.)

## Chain

- superficie: SOSTENIDO — `ngx_mail_smtp_auth()` reached from the SMTP command
  dispatcher (`ngx_mail_smtp_auth_state`, `:538-539`), mask value read from the
  live srv conf.
- lectura: SOSTENIDO (2026-10-09) — against `smtp_auth cram-md5;` with an
  always-OK auth_http backend, `AUTH PLAIN` and `AUTH LOGIN` both completed with
  `235 2.0.0 OK`, and the counter-probe `AUTH EXTERNAL` was rejected with
  `500 5.5.1 Invalid command`. `capture/verdict.json`, `capture/rc.txt`.
- Configuration contract: the finding is a **bypass of the `smtp_auth`
  restriction**, so it only bites when the operator narrows the mask (e.g. to
  `cram-md5`). The default mask is `plain login` (`:160-164`), where PLAIN/LOGIN
  are intended to work anyway. The PoC's config delta vs. default is exactly
  `smtp_auth cram-md5;`.

## PoC (MEASURED 2026-10-09, rc=0)

Self-contained kit: Dockerfile builds nginx `--with-mail` from the pinned
tarball; `nginx.conf` sets `smtp_auth cram-md5;`; `auth_http.py` answers
`Auth-Status: OK` (so the mask is the only possible gate); `dummy_upstream.py`
is the post-auth proxy target (it must answer the proxy's own EHLO with 250, or
nginx never emits the 235 — see README "Why the dummy answers EHLO");
`smtp_client.py` runs the three sessions.

Measured (`capture/verdict.json`):

| leg | method | mask gate | result |
|---|---|---|---|
| bypass | AUTH PLAIN | absent (mask=cram-md5) | `235 2.0.0 OK` |
| bypass | AUTH LOGIN | absent | `235 2.0.0 OK` |
| contraste | AUTH EXTERNAL | present | `500 5.5.1 Invalid command` |

EHLO advertised `250 AUTH CRAM-MD5` while PLAIN/LOGIN still succeeded — the
advertisement/enforcement mismatch in one line.

rc contract (`exploit.sh`): PLAIN and LOGIN both reach 235 **and** a
mask-gated method is rejected -> rc=0. Measured: PLAIN=235, LOGIN=235,
EXTERNAL=500, `rc=0`.

## Where the finding would land

- A security-control bypass: the operator's `smtp_auth` restriction does not
  disable the cleartext mechanisms it appears to disable. A client that wants
  PLAIN/LOGIN gets the prompts and its credentials are processed by the
  auth_http backend in cleartext.
- **Not** an authentication bypass: the auth_http backend still decides
  success. What is bypassed is the method mask, not the identity check. Impact
  ceiling = configuration/policy bypass (terminal), not RCE.

## Owner

Orquestador. Differential PoC measured 2026-10-09 (rc=0,
`capture/verdict.json`); mechanism confirmed by source, impact ceiling =
`smtp_auth` policy bypass.
