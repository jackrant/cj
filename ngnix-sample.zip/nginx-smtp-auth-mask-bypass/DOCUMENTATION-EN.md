# DOCUMENTATION - nginx-smtp-auth-mask-bypass

Reproducible PoC proving that an nginx mail server configured with `smtp_auth cram-md5;` still
completes `AUTH PLAIN` and `AUTH LOGIN`, even though the mask enables only CRAM-MD5. The mask is
consulted for CRAM-MD5 and EXTERNAL but not for the two cleartext mechanisms, so the restriction
an operator wrote to disable cleartext credential mechanisms is ineffective against a client
that asks for them, while the EHLO capability line advertises otherwise. The impact is a
`smtp_auth` policy bypass, not an authentication bypass: the auth_http backend still decides
success, and no memory-safety primitive is claimed.

- **Class:** `smtp_auth` policy bypass. Not an authentication bypass.
- **Impact ceiling:** the methods removed from the mask remain usable, and the credentials a
  client sends for them are processed by the auth_http backend in cleartext. No memory-safety
  primitive is claimed.
- **Auth / precondition:** no credential bypass; auth_http still decides success. The operator
  must have narrowed `smtp_auth` to something like `cram-md5`.
- **Default config:** NO. With the default mask (`PLAIN|LOGIN`) the two mechanisms are already
  enabled, so the bypass only bites once an operator narrows the mask.
- **Target:** nginx built `--with-mail` from the pinned 1.31.6 tarball; the audited tree is
  1.31.7.

## 1. Position yourself in the directory

This entry lives at `nginx/nginx-smtp-auth-mask-bypass/`. From the kit root:

```
cd nginx/nginx-smtp-auth-mask-bypass
```

All commands below are relative to this directory (or, where stated, to the kit root), and no
absolute path is used.

## 2. Files and what each one does

| File | Function |
|---|---|
| `Dockerfile` | Builds nginx `--with-mail` from the pinned 1.31.6 tarball on a pinned `python:3.12-slim-trixie` base digest. |
| `nginx.conf` | `mail {}` with `smtp_auth cram-md5;`, `listen 40225`, `auth_http 127.0.0.1:9000/auth`. |
| `auth_http.py` | auth_http backend, always `Auth-Status: OK`; dials `127.0.0.1:12525` after auth. |
| `dummy_upstream.py` | Minimal SMTP responder used as the post-auth proxy target. |
| `smtp_client.py` | Three sessions: PLAIN, LOGIN, EXTERNAL; prints `CLIENT_VERDICT {...}`. |
| `entrypoint.sh` | Starts both python listeners, then `nginx -g 'daemon off;'`. |
| `exploit.sh` | Build, run, measure, verdict, and the rc contract; EXIT-trap cleanup. |
| `README.md` | The entry's source-of-truth document (mechanism, legs, rc contract). |
| `SPEC.md` | The entry's spec sheet. |
| `capture/` | Run logs, `verdict.json`, `rc.txt` (created at runtime). |

## 3. The target source

The vulnerable function is `ngx_mail_smtp_auth()` at `src/mail/ngx_mail_smtp_handler.c:702`. It
switches on the parsed AUTH method: `NGX_MAIL_AUTH_LOGIN` at `:727` and `NGX_MAIL_AUTH_PLAIN` at
`:741` do not test the mask, while `NGX_MAIL_AUTH_CRAM_MD5` at `:748` tests it at `:750` and
`NGX_MAIL_AUTH_EXTERNAL` at `:769` tests it at `:771`. The mask `sscf->auth_methods` is merged
to the default `PLAIN|LOGIN` at `ngx_mail_smtp_module.c:160-164` and advertised in the EHLO
capability line at `:212-217`. A masked-out method is rejected with `smtp_invalid_command[] =
"500 5.5.1 Invalid command"` at `ngx_mail_smtp_handler.c:45`, dispatched at `:613-616`.

The proxy leg that explains why the PoC needs a responding upstream: after `Auth-Status: OK`,
nginx dials `Auth-Server:Auth-Port` and runs `ngx_mail_proxy_smtp_handler`, which sends its own
`EHLO <server_name>` upstream and waits for a `250` (`ngx_mail_proxy_read_response`, state
`ngx_smtp_helo`, `src/mail/ngx_mail_proxy_module.c:1114-1122`); only then does it copy
`smtp_auth_ok` (`"235 2.0.0 OK"`, `:133`) to the client (`:832`).

The build context is the entry directory. The Dockerfile fetches Debian packages and one
`nginx.org` tarball (sha256-verified) on first build, so it needs network access.

## 4. Build and start

```
./exploit.sh
```

The script builds the image (from the pinned 1.31.6 tarball), starts nginx plus both python
listeners, runs the three legs, writes the verdict, and cleans up on exit. Only host port
`127.0.0.1:40225` is published; the container and network are removed on exit. There is no
separate manual start needed, and the published port is only for a human.

### Exit contract

| rc | Meaning |
|---|---|
| `0` | `AUTH PLAIN` and `AUTH LOGIN` both return `235` AND `AUTH EXTERNAL` returns a 5xx. |
| `1` | Not demonstrated (honest negative). |

## 5. Reproduce - execution order

1. Build the image and start the container; wait for port `40225`.
2. **BYPASS 1** (`AUTH PLAIN`): EHLO, then `AUTH PLAIN` with base64 of `\0user\0pass`. Expected
   `235 2.0.0 OK` although `plain` is not in the mask.
3. **BYPASS 2** (`AUTH LOGIN`): EHLO, then `AUTH LOGIN`, sending the base64 user and then the
   base64 pass. Expected `235 2.0.0 OK` although `login` is not in the mask.
4. **CONTRASTE** (`AUTH EXTERNAL`): gated by the mask, so expected `500 5.5.1 Invalid command`.
   This is the negative control.
5. Read `CLIENT_VERDICT` from `smtp_client.py` and write `capture/verdict.json` and
   `capture/rc.txt`; tear down the container and network.

## 6. The vector(s) and the controls

Vectors, from the README's legs:

| Vector | Client action | Mask state | Observed |
|---|---|---|---|
| `AUTH PLAIN` | send `base64(\0user\0pass)` | `plain` not in mask | `235 2.0.0 OK` |
| `AUTH LOGIN` | send base64 user then base64 pass | `login` not in mask | `235 2.0.0 OK` |

Controls (the README's negative control):

| Control | Client action | Expected | Observed |
|---|---|---|---|
| `AUTH EXTERNAL` | masked-out method | `500 5.5.1 Invalid command` | `500` |

The contrast leg proves the mask is consulted for the methods that test it, so the bypass is
method-specific and not a blanket "everything is accepted".

## 7. Conditions

1. The operator has narrowed `smtp_auth` to a mask that excludes the cleartext mechanisms, for
   example `smtp_auth cram-md5;`.
2. The EHLO capability line advertises the narrowed mask (`250 AUTH CRAM-MD5`), so a client that
   trusts the advertisement would not try PLAIN or LOGIN.
3. The auth_http backend answers `Auth-Status: OK`; the post-auth proxy leg requires an upstream
   that answers EHLO/HELO with `250`, otherwise nginx hangs and the client never sees `235`.

## 8. Against a real / deployed target

(a) **Target characteristics.** An nginx mail (SMTP) server with `--with-mail` and a
`smtp_auth` mask narrowed to exclude plain/login. The entry does not measure a deployment with
the default mask, where the bypass has no effect.

(b) **Chain position.** This is a downgrade step: a client can force a cleartext credential
mechanism the operator tried to disable, so credentials are exposed to the auth_http path in
cleartext when the operator expected only CRAM-MD5. It is a precondition to credential capture,
not an execution end state.

(c) **Build / run against a real target.** Connect to the SMTP port, EHLO, and send
`AUTH PLAIN` (or `AUTH LOGIN`); observe the `235` even though the mask excludes that method.

(d) **What a PoC would have to change.** Only the host and port. The upstream stub must answer
EHLO/HELO with `250` for the proxy leg to complete, or the observation is a hang, not a bypass.

## 9. Measured / not measured

Measured (from the README and `capture/verdict.json`): `AUTH PLAIN` returns `235`, `AUTH LOGIN`
returns `235`, and `AUTH EXTERNAL` returns `500`; `ehlo_auth_advertised` is `250 AUTH CRAM-MD5`;
`bypass_shown` is true and `contraprobada_rejected` is true; `build_rc=0`, `client_rc=0`,
`rc=0`. Measured 2026-10-09.

