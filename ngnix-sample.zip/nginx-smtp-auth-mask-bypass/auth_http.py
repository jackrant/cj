#!/usr/bin/env python3
"""Minimal nginx mail auth_http backend.

Always answers the nginx auth_http request with Auth-Status: OK. Its only job
is to remove every other gate from the AUTH path so that the smtp_auth mask is
the ONLY thing that can reject a method.

nginx sends an HTTP/1.0 GET with Auth-* request headers; we reply with the
Auth-Server / Auth-Port the proxy step will dial, plus Auth-Status: OK.
"""

import socket
import threading

HOST = "127.0.0.1"
PORT = 9000

AUTH_SERVER = "127.0.0.1"
AUTH_PORT = 12525


def _read_request(conn):
    data = b""
    while b"\r\n\r\n" not in data:
        chunk = conn.recv(4096)
        if not chunk:
            break
        data += chunk
        if len(data) > 65536:
            break
    return data.decode("latin1", "replace")


def _handle(conn):
    try:
        req = _read_request(conn)
        user = "testuser"
        for line in req.split("\r\n"):
            if line.lower().startswith("auth-user:"):
                user = line.split(":", 1)[1].strip() or user
        resp = (
            "HTTP/1.0 200 OK\r\n"
            "Auth-Status: OK\r\n"
            "Auth-Server: %s\r\n"
            "Auth-Port: %d\r\n"
            "Auth-User: %s\r\n"
            "\r\n" % (AUTH_SERVER, AUTH_PORT, user)
        )
        conn.sendall(resp.encode("latin1"))
    except OSError:
        pass
    finally:
        try:
            conn.close()
        except OSError:
            pass


def main():
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind((HOST, PORT))
    srv.listen(16)
    print("auth_http: listening on %s:%d, always Auth-Status: OK" % (HOST, PORT),
          flush=True)
    while True:
        conn, _ = srv.accept()
        threading.Thread(target=_handle, args=(conn,), daemon=True).start()


if __name__ == "__main__":
    main()
