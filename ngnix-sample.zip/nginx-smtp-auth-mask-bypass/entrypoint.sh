#!/bin/sh
# Container entrypoint: start the always-OK auth_http backend, the dummy proxy
# target, then nginx in the foreground.
set -eu

python3 /opt/kit/auth_http.py >>/var/log/nginx/kit.log 2>&1 &
python3 /opt/kit/dummy_upstream.py >>/var/log/nginx/kit.log 2>&1 &

i=0
while [ "$i" -lt 50 ]; do
    if python3 - <<'PY'
import socket
for p in (9000, 12525):
    s = socket.socket()
    s.settimeout(0.2)
    try:
        s.connect(("127.0.0.1", p))
    except OSError:
        raise SystemExit(1)
    finally:
        s.close()
PY
    then
        break
    fi
    i=$((i + 1))
    sleep 0.1
done

exec /usr/local/nginx/sbin/nginx -g 'daemon off;'
