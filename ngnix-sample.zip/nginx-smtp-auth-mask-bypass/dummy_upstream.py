#!/usr/bin/env python3
"""Dummy SMTP upstream used only as the proxy target after a successful auth.

nginx, after Auth-Status: OK, dials Auth-Server:Auth-Port and switches the
client into proxy mode. Before it tells the client "235", the proxy itself
connects here, sends its own EHLO, and waits for a 250 (ngx_mail_proxy_read_response,
state ngx_smtp_helo). So this stub must be a minimally well-behaved SMTP server,
not just a banner: it answers EHLO/HELO so the proxy step completes and nginx
emits the 235. Its answer is irrelevant to the auth decision -- nginx already
made that decision from the auth_http reply.
"""

import socket
import threading

HOST = "127.0.0.1"
PORT = 12525


def _reply(line):
    """Return the upstream reply for one command line (upper-cased verb)."""
    u = line.upper()
    if u.startswith("EHLO") or u.startswith("HELO"):
        return b"250 dummy-upstream\r\n"
    if u.startswith("AUTH"):
        return b"235 2.0.0 OK\r\n"
    if u.startswith("MAIL FROM"):
        return b"250 2.1.0 Ok\r\n"
    if u.startswith("RCPT TO"):
        return b"250 2.1.5 Ok\r\n"
    if u.startswith("DATA"):
        return b"354 End data with <CR><LF>.<CR><LF>\r\n"
    if u.startswith("QUIT"):
        return b"221 2.0.0 Bye\r\n"
    if u.startswith("RSET") or u.startswith("NOOP"):
        return b"250 2.0.0 Ok\r\n"
    return b"250 2.0.0 Ok\r\n"


def _handle(conn):
    try:
        conn.sendall(b"220 dummy-upstream ESMTP ready\r\n")
        f = conn.makefile("rb")
        while True:
            raw = f.readline()
            if raw == b"":
                break
            line = raw.decode("latin1", "replace").rstrip("\r\n")
            if line == ".":
                conn.sendall(b"250 2.0.0 Ok: queued\r\n")
                continue
            conn.sendall(_reply(line))
    except OSError:
        pass
    finally:
        try:
            conn.close()
        except OSError:
            pass


def main():
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind((HOST, PORT))
    srv.listen(16)
    print("dummy_upstream: listening on %s:%d" % (HOST, PORT), flush=True)
    while True:
        conn, _ = srv.accept()
        threading.Thread(target=_handle, args=(conn,), daemon=True).start()


if __name__ == "__main__":
    main()
